
import { useState } from 'react';
import './App.css';
import Login from './components/Login';
import SignUp from './components/SignUp';
import Router from './components/Router';

function App() {
  const [isLogin,setIsLogin] = useState(true)

  return (
    <div className="App">
      <Router />
    </div>
  );
}

export default App;
